#!/usr/bin/env bash
# Instalador do Assistente (Ubuntu/Debian e outros Linux com systemd)
# - instala o Ollama (se faltar), libera SOMENTE o endereço do sistema e baixa o modelo
# - o Ollama continua escutando apenas neste computador (127.0.0.1): nada é exposto na rede
#
# Uso:   bash instalar-assistente.sh
#        bash instalar-assistente.sh --host https://seusite.com --modelo qwen2.5:7b -y
#        bash instalar-assistente.sh --remover
set -uo pipefail

LOG="$HOME/instalar-assistente.log"
exec > >(tee -a "$LOG") 2>&1

HOSTS=""; MODELO=""; REMOVER=0; SIM=0
while [ $# -gt 0 ]; do
  case "$1" in
    --host)   HOSTS="${2:-}"; shift 2 ;;
    --modelo) MODELO="${2:-}"; shift 2 ;;
    --remover) REMOVER=1; shift ;;
    -y|--sim) SIM=1; shift ;;
    -h|--ajuda) sed -n '2,9p' "$0"; exit 0 ;;
    *) echo "Opção desconhecida: $1"; exit 1 ;;
  esac
done

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m ✔ %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m ! %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31m ✖ %s\033[0m\n' "$*"; echo "Log completo em: $LOG"; exit 1; }
DROPIN_DIR=/etc/systemd/system/ollama.service.d
# "zz-" garante que este arquivo vale por último, mesmo que exista um override.conf antigo
DROPIN="$DROPIN_DIR/zz-assistente.conf"

echo "Instalador do Assistente - $(date '+%d/%m/%Y %H:%M')"

# ---------------------------------------------------------------- remover
if [ "$REMOVER" = 1 ]; then
  say "Removendo a configuração do assistente"
  sudo rm -f "$DROPIN" && sudo systemctl daemon-reload && sudo systemctl restart ollama
  ok "Configuração removida. O Ollama voltou ao padrão (só aceita o próprio computador)."
  echo "Para apagar modelos baixados:  ollama list   e depois   ollama rm NOME"
  exit 0
fi

command -v curl >/dev/null || die "Falta o curl. Rode: sudo apt install -y curl"
command -v sudo >/dev/null || die "Falta o sudo."

# ---------------------------------------------------------------- hardware
say "1/6  Verificando o computador"
RAM_GB=$(awk '/MemTotal/ {printf "%d", $2/1024/1024}' /proc/meminfo)
GPU_MB=0
if command -v nvidia-smi >/dev/null 2>&1; then
  GPU_MB=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -dc '0-9')
  GPU_MB=${GPU_MB:-0}
fi
CPUS=$(nproc 2>/dev/null || echo "?")
DISCO_GB=$(df -BG --output=avail "$HOME" 2>/dev/null | tail -1 | tr -dc '0-9')
echo "Memória: ${RAM_GB} GB | Núcleos: ${CPUS} | GPU NVIDIA: ${GPU_MB} MB | Disco livre: ${DISCO_GB:-?} GB"

if   [ "$GPU_MB" -ge 12000 ] && [ "$RAM_GB" -ge 16 ]; then REC="qwen2.5:14b"
elif [ "$RAM_GB" -ge 12 ]; then REC="qwen2.5:7b"
elif [ "$RAM_GB" -ge 6 ];  then REC="qwen2.5:3b"
else REC="qwen2.5:1.5b"; fi
[ "$RAM_GB" -lt 12 ] && [ "$GPU_MB" -lt 8000 ] && warn "Memória abaixo de 12 GB: o assistente funciona, mas com modelo pequeno ele erra mais ao montar consultas."

if [ -z "$MODELO" ]; then
  echo "Modelo recomendado para este computador: $REC"
  if [ "$SIM" = 0 ]; then
    echo "Opções: qwen2.5:0.5b (teste mínimo) | qwen2.5:1.5b | qwen2.5:3b | qwen2.5:7b | qwen2.5:14b"
    read -r -p "Modelo [Enter = $REC]: " MODELO
  fi
  MODELO=${MODELO:-$REC}
fi
ok "Modelo escolhido: $MODELO"

# ---------------------------------------------------------------- endereço do sistema
say "2/6  Endereço do sistema"
if [ -z "$HOSTS" ]; then
  echo "Digite o endereço onde o sistema está publicado, como aparece na barra do navegador."
  echo "Exemplo: https://seusite.com   (para mais de um, separe por vírgula)"
  read -r -p "Endereço: " HOSTS
fi
ORIGENS=""
IFS=',' read -ra LISTA <<< "$HOSTS"
for h in "${LISTA[@]}"; do
  h=$(echo "$h" | tr -d '[:space:]' | sed -E 's#^(https?://[^/]+).*#\1#')
  [[ "$h" =~ ^https?://[A-Za-z0-9._:-]+$ ]] || die "Endereço inválido: '$h'. Use o formato https://seusite.com"
  [ "$h" = "null" ] && die "Endereço 'null' não é permitido."
  ORIGENS="${ORIGENS:+$ORIGENS,}$h"
done
ok "Endereços liberados: $ORIGENS"

# ---------------------------------------------------------------- ollama
say "3/6  Instalando o Ollama"
if command -v ollama >/dev/null 2>&1; then
  ok "Ollama já instalado ($(ollama --version 2>&1 | tail -1))"
else
  curl -fsSL https://ollama.com/install.sh | sh || die "Falha ao instalar o Ollama."
  ok "Ollama instalado"
fi

say "4/6  Configurando e reiniciando o serviço"
command -v systemctl >/dev/null || die "Este instalador precisa de systemd. Veja o LEIAME para configurar manualmente."
systemctl list-unit-files 2>/dev/null | grep -q '^ollama.service' || die "Serviço ollama.service não encontrado."
sudo mkdir -p "$DROPIN_DIR"
printf '[Service]\nEnvironment="OLLAMA_ORIGINS=%s"\nEnvironment="OLLAMA_KEEP_ALIVE=30m"\n' "$ORIGENS" | sudo tee "$DROPIN" >/dev/null
sudo systemctl daemon-reload
sudo systemctl restart ollama
if systemctl show ollama -p Environment 2>/dev/null | grep -Eq 'OLLAMA_HOST=(0\.0\.0\.0|:)'; then
  warn "O Ollama está configurado para aceitar conexões de OUTROS computadores da rede (OLLAMA_HOST). Para este uso isso não é necessário e não é recomendado."
fi
for i in $(seq 1 30); do
  curl -fs http://127.0.0.1:11434/api/version >/dev/null 2>&1 && break
  sleep 1
done
curl -fs http://127.0.0.1:11434/api/version >/dev/null 2>&1 || die "O Ollama não respondeu. Veja: journalctl -u ollama -e"
ok "Serviço no ar"

# ---------------------------------------------------------------- modelo
say "5/6  Baixando o modelo $MODELO (pode demorar)"
ollama pull "$MODELO" || die "Falha ao baixar o modelo. Confira a internet e o espaço em disco."
ok "Modelo baixado"

# ---------------------------------------------------------------- verificação
say "6/6  Verificando"
FALHAS=0
IFS=',' read -ra LISTA <<< "$ORIGENS"
for o in "${LISTA[@]}"; do
  CAB=$(curl -s -D - -o /dev/null -H "Origin: $o" http://127.0.0.1:11434/api/tags | tr -d '\r')
  if echo "$CAB" | grep -qi "^access-control-allow-origin: $o"; then ok "Liberado para $o"
  else warn "NÃO liberado para $o"; FALHAS=1; fi
done
CAB=$(curl -s -o /dev/null -w '%{http_code}' -H "Origin: https://site-nao-autorizado.example" http://127.0.0.1:11434/api/tags)
[ "$CAB" = "403" ] && ok "Sites não autorizados são recusados (403)" || warn "Um site não autorizado recebeu código $CAB (esperado 403)"

echo "Teste rápido do modelo (a primeira resposta é a mais lenta)..."
RESP=$(curl -s --max-time 300 http://127.0.0.1:11434/api/generate -d "{\"model\":\"$MODELO\",\"prompt\":\"Responda apenas: ok\",\"stream\":false,\"keep_alive\":\"30m\"}" | sed -n 's/.*"response":"\([^"]*\)".*/\1/p')
[ -n "$RESP" ] && ok "Modelo respondeu: $RESP" || { warn "O modelo não respondeu no teste."; FALHAS=1; }

echo
if [ "$FALHAS" = 0 ]; then
  printf '\033[1;32mTUDO PRONTO.\033[0m Abra o sistema no Chrome/Edge, entre e clique na aba Assistente.\n'
else
  printf '\033[1;33mTerminou com avisos.\033[0m Leia as linhas "!" acima. Log: %s\n' "$LOG"
fi
echo "Se o Chrome perguntar sobre acesso à rede local / outros dispositivos, clique em Permitir."
