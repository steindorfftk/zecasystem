﻿# Instalador do Assistente (Windows 10/11, PowerShell 5.1 ou superior)
# - instala o Ollama (se faltar), libera SOMENTE o endereco do sistema e baixa o modelo
# - o Ollama continua escutando apenas neste computador (127.0.0.1): nada e exposto na rede
#
# Uso normal: de dois cliques em INSTALAR-WINDOWS.bat
# Avancado:   powershell -ExecutionPolicy Bypass -File instalar-assistente.ps1 -Site https://seusite.com -Modelo qwen2.5:7b -Sim
#             powershell -ExecutionPolicy Bypass -File instalar-assistente.ps1 -Remover
param(
  [string]$Site = '',
  [string]$Modelo = '',
  [switch]$Remover,
  [switch]$Sim
)
$ErrorActionPreference = 'Stop'
$log = Join-Path $env:USERPROFILE 'instalar-assistente.log'
try { Start-Transcript -Path $log -Append | Out-Null } catch {}

function Say($t)  { Write-Host ''; Write-Host "==> $t" -ForegroundColor Cyan }
function Ok($t)   { Write-Host " [OK] $t" -ForegroundColor Green }
function Warn($t) { Write-Host " [!]  $t" -ForegroundColor Yellow }
function Die($t)  { Write-Host " [X]  $t" -ForegroundColor Red; Write-Host "Log completo em: $log"; try { Stop-Transcript | Out-Null } catch {}; exit 1 }

function Find-Ollama {
  $c = Get-Command ollama -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  foreach ($p in @("$env:LOCALAPPDATA\Programs\Ollama\ollama.exe", "$env:ProgramFiles\Ollama\ollama.exe")) {
    if (Test-Path $p) { return $p }
  }
  return $null
}
function Wait-Ollama($segundos) {
  for ($i = 0; $i -lt $segundos; $i++) {
    try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/version' -TimeoutSec 2 | Out-Null; return $true } catch { Start-Sleep -Seconds 1 }
  }
  return $false
}
function Restart-Ollama($exe) {
  Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -in @('ollama app', 'ollama', 'ollama_llama_server') } | Stop-Process -Force -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 2
  $app = Join-Path (Split-Path $exe) 'ollama app.exe'
  if (Test-Path $app) { Start-Process -FilePath $app } else { Start-Process -FilePath $exe -ArgumentList 'serve' -WindowStyle Hidden }
}

Write-Host "Instalador do Assistente - $(Get-Date -Format 'dd/MM/yyyy HH:mm')"

# ---------------------------------------------------------------- remover
if ($Remover) {
  Say 'Removendo a configuracao do assistente'
  [Environment]::SetEnvironmentVariable('OLLAMA_ORIGINS', $null, 'User')
  [Environment]::SetEnvironmentVariable('OLLAMA_KEEP_ALIVE', $null, 'User')
  Remove-Item Env:OLLAMA_ORIGINS -ErrorAction SilentlyContinue
  Remove-Item Env:OLLAMA_KEEP_ALIVE -ErrorAction SilentlyContinue
  $exe = Find-Ollama
  if ($exe) { Restart-Ollama $exe }
  Ok 'Configuracao removida. O Ollama voltou ao padrao (so aceita o proprio computador).'
  Write-Host 'Para apagar modelos baixados, abra um terminal e rode:  ollama list   e depois   ollama rm NOME'
  try { Stop-Transcript | Out-Null } catch {}
  exit 0
}

# ---------------------------------------------------------------- hardware
Say '1/6  Verificando o computador'
$ramGB = [math]::Floor((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
$gpuMB = 0
if (Get-Command nvidia-smi -ErrorAction SilentlyContinue) {
  try { $gpuMB = [int](((& nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits) | Select-Object -First 1).Trim()) } catch { $gpuMB = 0 }
}
$discoGB = [math]::Floor((Get-PSDrive -Name ($env:USERPROFILE.Substring(0, 1))).Free / 1GB)
Write-Host "Memoria: $ramGB GB | Nucleos: $env:NUMBER_OF_PROCESSORS | GPU NVIDIA: $gpuMB MB | Disco livre: $discoGB GB"

if     ($gpuMB -ge 12000 -and $ramGB -ge 16) { $rec = 'qwen2.5:14b' }
elseif ($ramGB -ge 12) { $rec = 'qwen2.5:7b' }
elseif ($ramGB -ge 6)  { $rec = 'qwen2.5:3b' }
else                   { $rec = 'qwen2.5:1.5b' }
if ($ramGB -lt 12 -and $gpuMB -lt 8000) { Warn 'Memoria abaixo de 12 GB: o assistente funciona, mas com modelo pequeno ele erra mais ao montar consultas.' }

if (-not $Modelo) {
  Write-Host "Modelo recomendado para este computador: $rec"
  if (-not $Sim) {
    Write-Host 'Opcoes: qwen2.5:0.5b (teste minimo) | qwen2.5:1.5b | qwen2.5:3b | qwen2.5:7b | qwen2.5:14b'
    $Modelo = Read-Host "Modelo [Enter = $rec]"
  }
  if (-not $Modelo) { $Modelo = $rec }
}
if ($Modelo -notmatch '^[A-Za-z0-9._:/-]+$') { Die "Nome de modelo invalido: $Modelo" }
Ok "Modelo escolhido: $Modelo"

# ---------------------------------------------------------------- endereco do sistema
Say '2/6  Endereco do sistema'
if (-not $Site) {
  Write-Host 'Digite o endereco onde o sistema esta publicado, como aparece na barra do navegador.'
  Write-Host 'Exemplo: https://seusite.com   (para mais de um, separe por virgula)'
  $Site = Read-Host 'Endereco'
}
$lista = @()
foreach ($h in ($Site -split ',')) {
  $h = ($h -replace '\s', '')
  if ($h -match '^(https?://[^/]+)') { $h = $Matches[1] }
  if ($h -notmatch '^https?://[A-Za-z0-9._:-]+$') { Die "Endereco invalido: '$h'. Use o formato https://seusite.com" }
  $lista += $h
}
$origens = ($lista -join ',')
Ok "Enderecos liberados: $origens"

# ---------------------------------------------------------------- ollama
Say '3/6  Instalando o Ollama'
$exe = Find-Ollama
if ($exe) {
  Ok "Ollama ja instalado ($exe)"
} else {
  $feito = $false
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    Write-Host 'Instalando com o winget...'
    try { & winget install -e --id Ollama.Ollama --accept-package-agreements --accept-source-agreements --silent; if ($LASTEXITCODE -eq 0) { $feito = $true } } catch {}
  }
  if (-not $feito -or -not (Find-Ollama)) {
    Write-Host 'Baixando o instalador oficial (ollama.com)...'
    $setup = Join-Path $env:TEMP 'OllamaSetup.exe'
    try {
      Invoke-WebRequest -Uri 'https://ollama.com/download/OllamaSetup.exe' -OutFile $setup -UseBasicParsing
      Start-Process -FilePath $setup -ArgumentList '/SILENT' -Wait
    } catch { Die 'Nao consegui baixar/instalar o Ollama. Instale manualmente em https://ollama.com/download e rode este instalador de novo.' }
  }
  $exe = Find-Ollama
  if (-not $exe) { Die 'O Ollama nao foi encontrado depois da instalacao. Instale manualmente em https://ollama.com/download e rode este instalador de novo.' }
  Ok "Ollama instalado ($exe)"
}

Say '4/6  Configurando e reiniciando o Ollama'
[Environment]::SetEnvironmentVariable('OLLAMA_ORIGINS', $origens, 'User')
[Environment]::SetEnvironmentVariable('OLLAMA_KEEP_ALIVE', '30m', 'User')
$env:OLLAMA_ORIGINS = $origens
$env:OLLAMA_KEEP_ALIVE = '30m'
if ($env:OLLAMA_HOST -match '0\.0\.0\.0') { Warn 'OLLAMA_HOST esta aceitando conexoes de OUTROS computadores da rede. Para este uso isso nao e necessario nem recomendado.' }
Restart-Ollama $exe
if (-not (Wait-Ollama 40)) { Die 'O Ollama nao respondeu. Abra o Ollama pelo menu Iniciar e rode este instalador de novo.' }
Ok 'Ollama no ar'

# ---------------------------------------------------------------- modelo
Say "5/6  Baixando o modelo $Modelo (pode demorar)"
& $exe pull $Modelo
if ($LASTEXITCODE -ne 0) { Die 'Falha ao baixar o modelo. Confira a internet e o espaco em disco.' }
Ok 'Modelo baixado'

# ---------------------------------------------------------------- verificacao
Say '6/6  Verificando'
$falhas = 0
foreach ($o in $lista) {
  try {
    $r = Invoke-WebRequest -Uri 'http://127.0.0.1:11434/api/tags' -Headers @{ Origin = $o } -UseBasicParsing -TimeoutSec 10
    if ($r.Headers['Access-Control-Allow-Origin'] -eq $o) { Ok "Liberado para $o" } else { Warn "NAO liberado para $o"; $falhas = 1 }
  } catch { Warn "Falha ao testar $o : $($_.Exception.Message)"; $falhas = 1 }
}
try {
  Invoke-WebRequest -Uri 'http://127.0.0.1:11434/api/tags' -Headers @{ Origin = 'https://site-nao-autorizado.example' } -UseBasicParsing -TimeoutSec 10 | Out-Null
  Warn 'Um site nao autorizado foi aceito (esperado: recusar).'
} catch { Ok 'Sites nao autorizados sao recusados (403)' }

Write-Host 'Teste rapido do modelo (a primeira resposta e a mais lenta)...'
try {
  $corpo = @{ model = $Modelo; prompt = 'Responda apenas: ok'; stream = $false; keep_alive = '30m' } | ConvertTo-Json
  $resp = Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:11434/api/generate' -Body $corpo -ContentType 'application/json' -TimeoutSec 300
  Ok "Modelo respondeu: $($resp.response.Trim())"
} catch { Warn "O modelo nao respondeu no teste: $($_.Exception.Message)"; $falhas = 1 }

Write-Host ''
if ($falhas -eq 0) { Write-Host 'TUDO PRONTO. Abra o sistema no Chrome/Edge, entre e clique na aba Assistente.' -ForegroundColor Green }
else { Write-Host "Terminou com avisos. Leia as linhas [!] acima. Log: $log" -ForegroundColor Yellow }
Write-Host 'Se o Chrome perguntar sobre acesso a rede local / outros dispositivos, clique em Permitir.'
try { Stop-Transcript | Out-Null } catch {}
