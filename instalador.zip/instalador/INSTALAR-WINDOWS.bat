@echo off
title Instalador do Assistente
cd /d "%~dp0"
echo.
echo  Instalador do Assistente
echo  ------------------------
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar-assistente.ps1"
echo.
echo  Pressione qualquer tecla para fechar.
pause >nul
